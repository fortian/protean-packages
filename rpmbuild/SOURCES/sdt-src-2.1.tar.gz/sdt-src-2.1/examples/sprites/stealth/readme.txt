SDT-3D Parameters for this model

length = 20.08 meters

light = off

