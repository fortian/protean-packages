SDT-3D Parameters for this model

length = 8.5 meters

light = off

