package mil.navy.nrl.sdt3d;

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwindx.examples.kml.KMLOrbitViewController;

public class SdtKMLOrbitViewController extends KMLOrbitViewController {

	public SdtKMLOrbitViewController(WorldWindow wwd) {
		super(wwd);
		// TODO Auto-generated constructor stub
	}

}
